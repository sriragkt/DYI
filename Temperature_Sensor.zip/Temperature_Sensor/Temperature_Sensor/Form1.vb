﻿Imports System.Net.Sockets
Imports System.Text
Imports System.ComponentModel
Imports System.Threading
Imports System.IO



Public Class Form1
    Dim chartData1 As String
    Dim filename As String = "C:\temp\" & Now.ToString("dd-MM-yyyy hh-mm-ss") & "_temperature_log.csv"

    Public Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Enabled = True
        RichTextBox1.Clear()
        RichTextBox1.Text = "Date" & "," & "Temperature in Fahreheit"
        On Error GoTo HERE
        Dim tcpClient As New System.Net.Sockets.TcpClient()
        Dim networkStream As NetworkStream
        tcpClient.Connect("192.168.0.2", 6660)
        networkStream = tcpClient.GetStream()

        If networkStream.CanWrite And networkStream.CanRead Then
            Button1.Visible = True

        Else
HERE:       Button1.Visible = False
            Button2.Enabled = False
            Button3.Visible = True
            Timer1.Stop()
            Timer2.Stop()
            MsgBox("Unable to establish connection with Micro controller")

        End If

        tcpClient.Dispose()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Timer1.Stop()
        Timer2.Stop()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim tempValue As String
        tempValue = TextBox1.Text
        Chart1.Series("temperature").Points.AddXY(Now.ToString, tempValue)
        'MsgBox(chartData1)
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        On Error GoTo tHERE
        Dim tcpClient As New System.Net.Sockets.TcpClient()
        Dim networkStream As NetworkStream
        tcpClient.Connect("192.168.0.2", 6660)
        networkStream = tcpClient.GetStream()

        If networkStream.CanWrite And networkStream.CanRead Then


            Dim sendBytes As [Byte]() = Encoding.ASCII.GetBytes("ABCD")
            networkStream.Write(sendBytes, 0, sendBytes.Length)
            'MsgBox(message)
            Thread.Sleep(100)

            Dim bytes(tcpClient.ReceiveBufferSize) As Byte
            Thread.Sleep(1000)
            networkStream.Read(bytes, 0, CInt(tcpClient.ReceiveBufferSize))
            Thread.Sleep(1000)
            ' Output the data received from the host to the console.
            Dim returndata As String = Encoding.ASCII.GetString(bytes)
            Console.WriteLine(("Host returned: " + returndata))
            ' returndata = Mid(returndata, 8)
            returndata = returndata.Replace(vbNullChar, "")
            returndata = Mid(returndata, 1, Len(returndata) - 4)
            chartData1 = Mid(returndata, 10)
            TextBox1.Text = chartData1
            'RichTextBox1.Text = returndata
            'RichTextBox1.Text += vbNewLine & returndata & ",  " & Now
            RichTextBox1.Text += vbNewLine & Now.ToString & "," & chartData1
            'RichTextBox1.SaveFile("c:\temp\templog.csv")
            On Error GoTo last
            File.WriteAllText(filename, RichTextBox1.Text)
            Thread.Sleep(10)
            tcpClient.Dispose()
        Else

tHERE:
            Timer1.Stop()
            Timer2.Stop()
            MsgBox("Unable to establish connection with Micro controller")
            Button1.Visible = False
            Button2.Enabled = False
            Button3.Visible = True
last:
            Timer1.Stop()
            Timer2.Stop()
            MsgBox("Unable to access log file")

        End If


        tcpClient.Dispose()
    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        On Error GoTo tHERE
        Dim tcpClient As New System.Net.Sockets.TcpClient()
        Dim networkStream As NetworkStream
        tcpClient.Connect("192.168.0.2", 6660)
        networkStream = tcpClient.GetStream()

        If networkStream.CanWrite And networkStream.CanRead Then
            Timer1.Start()
            Timer2.Start()
        Else
tHERE:      Timer2.Stop()
            Timer1.Stop()
            MsgBox("Unable to establish connection with Micro controller")
            tcpClient.Dispose()
        End If

    End Sub
End Class
